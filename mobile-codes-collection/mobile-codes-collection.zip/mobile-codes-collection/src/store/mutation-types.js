export const USER_INFO = 'user/fetch'
export const OPENID = 'user/openid'

export const CHANGE_ACTIVE_TYPE = 'type/change'
export const CHANGE_FOOTER_VISIBLE = 'foot/visible'
