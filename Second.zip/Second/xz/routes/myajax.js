//1.引入
const express=require('express');

//2.引入连接池模块
const pool=require('../pool.js');  //../ 连接上级目录下的js文件

//3.创建路由器对象
var router=express.Router();

//1.1测试服务器接收ajax请求的接口
router.get("/ajaxDemo",(req,res)=>{
  res.send("第一个ajax程序");
});
//1.2测试带参数的get请求
router.get("/ajaxDemo1",(req,res)=>{
	//接收参数
  var $uname=req.query.uname;
  var $upwd=req.query.upwd;
  if (!$uname)
  {
	  res.send("用户名未接收到");
	  return;
  }
  if (!$upwd)
  {
	  res.send("密码未接收到");
	  return;
  }
  res.send("用户名为:"+$uname+",密码为:"+$upwd);
});

//1.3 作业 用户登录接口（应该用post）  
router.get('/login_get',(req,res)=>{
	//接收参数
	var $uname=req.query.uname;
    var $upwd=req.query.upwd;
	console.log($uname);
	console.log($upwd);
	//验证数据是否为空401 402
	if (!$uname)
	{
		res.send("没有获取到用户名称");
		return;
	}
	if (!$upwd)
	{
		res.send("没有获取用户密码");
		return;
	}
    //执行SQL语句  查询用户表中，是否含有用户名和密码同时匹配的数据
    var sql="select * form xz_user where uname=? and upwd=?";
	pool.query(sql,[$uname,$upwd],function(err,result){   
	//判断数组的长度是否在于0，大于0就是登录成功	
	if (result.length>0)
	{
		res.send("登录成功");
	}else{
	    res.send("用户名或密码错误");
	}
});  
});
//4.post请求登录接口
router.post("/login_post",(req,res)=>{
    var $uname=req.body.uname;
    var $upwd=req.body.upwd;
	console.log($uname);
	console.log($upwd);
	//验证数据是否为空
	if (!$uname)
	{
		res.send("没有获取到用户名称");
		return;
	}
	if (!$upwd)
	{
		res.send("没有获取用户密码");
		return;
	}
    //执行SQL语句 
    var sql="select * from xz_user where uname=? and upwd=?";
	pool.query(sql,[$uname,$upwd],(err,result)=>{   
	//判断数组的长度是否在于0，大于0就是登录成功	
	if (result.length>0)
	{
		res.send("登录成功");
	}else{
	    res.send("用户名或密码错误");
	}
});
});

//5.使用get获取用户列表
router.get("/userlist",(req,res)=>{
    pool.query("select * from xz_user",(err,result)=>{
	   if(err) throw err;
	   res.send(result);
	});
});

//4.导出路由器对象 
module.exports=router;








