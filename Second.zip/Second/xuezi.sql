#设置客户端连接的编码
SET NAMES UTF8;
#丢弃数据库
#DROP DATABASE IF EXISTS xz;
#创建数据库
CREATE DATABASE xz CHARSET=UTF8;
#进入该数据库
USE xz;
#创建数据表01用户信息表xz_user;
CREATE TABLE 01_user(
  uid INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  uname VARCHAR(32),
  upwd  VARCHAR(32),
  email VARCHAR(64),
  phone VARCHAR(16) NOT NULL UNIQUE,
  avatar VARCHAR(128),
  user_name VARCHAR(32),
  gender INT
);

#创建数据表02用户地址表xz_receiver_address;
CREATE TABLE 02_receiver_address(
   aid  INT PRIMARY KEY AUTO_INCREMENT,
   user_id INT,
   receiver  VARCHAR(16),
   province  VARCHAR(16),
   city VARCHAR(16),
   county VARCHAR(16),
   address  VARCHAR(128),
   cellphone VARCHAR(16),
   fixedphone  VARCHAR(16),
   postcode CHAR(6),
   tag VARCHAR(16),
   is_default  BOOLEAN
);

#创建数据表03用户购物车表xz_shopping_cart;
CREATE TABLE 03_xz_shopping_cart(
   cid INT PRIMARY KEY AUTO_INCREMENT,
   user_id INT,
   product_id INT,
   count INT
);

#创建数据表04用户订单表xz_order;
CREATE TABLE 04_xz_order(
  aid INT  PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  address_id  INT,
  status  INT,
  order_time BIGINT,
  pay_time  BIGINT,
  deliver_time  BIGINT,
  received_time BIGINT
);

#创建数据表05用户订单详情表xz_order_detail;
CREATE TABLE xz_order_detail(
   did INT  PRIMARY KEY AUTO_INCREMENT,
   order_id INT,
   product_id INT,
   count INT
);

#创建数据表06_xz;
CREATE TABLE 06_xz_laptop_family(
    fid INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(32)
);

#创建数据表07_xz;
CREATE TABLE 07_xz_laptop(
    lid INT PRIMARY KEY AUTO_INCREMENT,
    family_id INT,
    product_id INT,
    title VARCHAR(128),
    subtitle VARCHAR(128),
    price DECIMAL(10,2),
    promise VARCHAR(64),
    spec VARCHAR(64),
    name VARCHAR(32),
    os VARCHAR(32),
    memory VARCHAR(32),
    resolution VARCHAR(32),
    video_card VARCHAR(32),
    cpu VARCHAR(32),
    video_memory VARCHAR(32),
    category VARCHAR(32),
    disk VARCHAR(32),
    details VARCHAR(1024),
    shelf_time BIGINT,
    sole_count INT,
    is_onsale BOOLEAN
);

#创建数据表08;
#CREATE TABLE 08_xz_laptop_pic(
    pid INT PRIMARY KEY AUTO_INCREMENT,
    laptop_id INT,
    sm VARCHAR(128),
    md VARCHAR(128),
    lg VARCHAR(128)
);

#创建数据表09;
#CREATE TABLE 09_xz_index_carousel(
   cid INT PRIMARY KEY AUTO_INCREMENT,
   img VARCHAR(128),
   title VARCHAR(64),
   href VARCHAR(128)
);

#创建数据表10_xz;
#CREATE TABLE 10_xz_index_product(
   pid INT PRIMARY KEY AUTO_INCREMENT,
   titlt VARCHAR(64),
   details VARCHAR(128),
   pic VARCHAR(128),
   price DECIMAL(10,2),
   href VARCHAR(128),
   seq_recommended TINYINT,
   seq_new_arrival TINYINT,
   seq_top_sale TINYINT
);


