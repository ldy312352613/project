<template>
	<div>
    <div class="summary">
      <div class="integral ta-c">
        <div class="integral__inner">
          <div class="integral__inner-title">目前积分</div>
          <div class="integral__inner-content">526</div>
        </div>
        <div class="ly ly-j ta-c ly-m">
          <div class="ta-c income">
            <div class="income__content">626</div>
            <div class="income__title">总收入(积分)</div>
          </div>
          <div class="parting-line"></div>
          <div class="ta-c outcome">
            <div class="outcome__content">100</div>
            <div class="outcome__title">总支出(积分)</div>
          </div>
        </div>
      </div>
    </div>
    <div class="integral-list">
      <h2 class="integral-list__title">收支明细</h2>
      <div class="integral-list__content">
        <div class="integral-list-item ly ly-j">
          <div>
            <div class="integral-list-item__title">步数兑换积分</div>
            <div class="integral-list-item__data">2018.10.14</div>
          </div>
          <div class="integral-list-item__content">+2积分</div>
        </div>
        <div class="integral-list-item ly ly-j">
          <div>
            <div class="integral-list-item__title">邀请新用户</div>
            <div class="integral-list-item__data">2018.10.14</div>
          </div>
          <div class="integral-list-item__content">+1积分</div>
        </div>
        <div class="integral-list-item ly ly-j">
          <div>
            <div class="integral-list-item__title">推荐人购买"菲力牛排组合套餐..."返积分</div>
            <div class="integral-list-item__data">2018.10.14</div>
          </div>
          <div class="integral-list-item__content">+20积分</div>
        </div>
        <div class="integral-list-item ly ly-j">
          <div>
            <div class="integral-list-item__title">积分抽奖</div>
            <div class="integral-list-item__data">2018.10.13</div>
          </div>
          <div class="integral-list-item__content integral-list-item__content--outcome">-10积分</div>
        </div>
        <div class="integral-list-item ly ly-j">
          <div>
            <div class="integral-list-item__title">签到奖励</div>
            <div class="integral-list-item__data">2018.10.13</div>
          </div>
          <div class="integral-list-item__content">+1积分</div>
        </div>
      </div>
    </div>
  </div>
</template>

<script src="./main.js"></script>
<style scoped src="./style.css"></style>