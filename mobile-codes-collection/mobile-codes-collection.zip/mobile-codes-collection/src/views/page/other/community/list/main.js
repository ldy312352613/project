import { addModel } from '@/service/api'
import Vue from 'vue'
import List from '@lucky-joel/vue-list'
Vue.use(List)

var openid = '1'
export default {
  data () {
    return {
      isShowComment: false,
      isShowBox: false
    }
  },
  methods: {},
  mounted () {}
}
