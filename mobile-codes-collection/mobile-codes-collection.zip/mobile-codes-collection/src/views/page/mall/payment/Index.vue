<template>
  <div>
    <div class="ta-c">
      <div class="notice-bar">请核实订单后支付，谨防诈骗</div>
    </div>
    <div class="summary ta-c">
      <div class="summary__title">商品名称商品名称</div>
      <div class="summary__value">¥10.00</div>
    </div>
    <div class="detail-list">
      <div class="ly ly-j detail-list__item">
        <div>收款方</div>
        <div>无限积点</div>
      </div>
      <div class="ly ly-j detail-list__item">
        <div>商品</div>
        <div>商品名称商品名称</div>
      </div>
      <div class="ly ly-j detail-list__item">
        <div>订单号</div>
        <div>ABCD1234567890123</div>
      </div>
    </div>
    <div class="ta-c pay-item">
      <a href="javascript:void(0);" class="pay-item__btn">立即支付</a>
    </div>
  </div>
</template>

<script src="./main.js"></script>

<style scoped src="./style.css"></style>