//1.引入
const express=require('express');

//5.引入连接池模块
const pool=require('../pool.js');  //../ 连接上级目录下的js文件

//2.创建路由器对象
var router=express.Router();

//3+6.添加路由01 用户注册
router.get('/reg',function(req,res){
	//获取get请求的数据
	var obj=req.query;
	//检测值是否为空
	if (!obj.uname)
	{
		res.send({code:401,msg:'uname required'});
		return;  //阻止往后执行
	}
	if (!obj.upwd)
	{
		res.send({code:402,msg:'upwd required'});
		return;
	}	
	if (!obj.phone)
	{
		res.send({code:403,msg:'phone required'});
		return;
	}
	if (!obj.email)
	{
		res.send({code:404,msg:'email required'});
		return;
	}
     //res.send('注册成功');
     //执行SQL命令  
     pool.query('INSERT INTO xz_user SET ?',[obj],function(err,result){
	     if(err) throw err;
		 console.log(result);
		 //判断是否注册成功
		 if(result.affectedRows>0){
		      res.send({code:200,msg:'reg suc'});
		 }
	});
});


//02 用户登录  
router.post('/login',function(req,res){
	var obj=req.body;
	console.log(obj);
	//验证数据是否为空401 402
	if (!obj.uname)
	{
		res.send({code:401,msg:'uname required'});
		return;
	}
	if (!obj.upwd)
	{
		res.send({code:402,msg:'upwd required'});
		return;
	}
//执行SQL语句   //查询用户表中，是否含有用户名和密码同时匹配的数据
pool.query('SELECT * FROM xz_user WHERE uname=? AND upwd=?',[obj.uname,obj.upwd],function(err,result){
    if(err)  throw err;
	console.log(result);
	//判断数组的长度是否在于0，大于0就是登录成功	
	if (result.length>0)
	{
		res.send({code:200,msg:'login suc'});
	}else{
	    res.send({code:301,msg:'login err'});
	}
});     

  //res.send('登录成功');可以删除了  写这个是为了看运行是否有问题，没问题就可以删除 
});

//添加router 03修改用户  get  /update
router.get('/update',function(req,res){
	//获取get请求数据
	var obj=req.query; 
	var n=400;
	//遍历对象属性，可以获取所有的属性
	for (var key in obj)
	{
		n++;
		//console.log(key,ojb[key]);
		//判断属性值是否为空
		if (!obj[key])
		{
			res.send({code:n,msg:key+'required'});   //添加变量n=400，n++; code:n，三步让
			return;                                   //判断的code码自增
		}
	}
	//执行SQL语句，修改数据
	pool.query('UPDATE xz_user SET phone=?,email=?,user_name=?,gender=? WHERE uid=?',
		[obj.phone,
		obj.email,
		obj.user_name,
		obj.gender,
		obj.uid],
		function(err,result){
	    if(err)  throw err;
	    if (result.affectedRows>0)
	    {
			res.send({code:200,msg:'update suc'});
	    }else{
		    res.send({code:301,msg:'update err'})
		}
	});
});
	

//router 04检索用户   get  /detail
router.get('/detail',function(req,res){
	var obj=req.query;   //获取get数据
	console.log(obj);
	if (!obj.uid)
	{
		res.send({code:401,msg:'uid required'});
		return;
	}
    //执行SQL语句
	pool.query('SELECT * FROM xz_user WHERE uid=?',[obj.uid],function(err,result){
	    if(err) throw err;
		res.send(result);
	});  
});


//router 05用户列表   get  /list
router.get('/list',function(req,res){
    var obj=req.query;	
	//验证是否为空 简写
	if (!obj.pno)obj.pno=1;
	if (!obj.count)obj.count=3;	
	//将传递的值转为整型
	obj.pno=parseInt(obj.pno);
	obj.count=parseInt(obj.count);
	//console.log(obj);  //{ pno: 1, count: 3 }  为空时打印的结果
	var start=(obj.pno-1)*obj.count;
	//执行SQL语句
	pool.query('SELECT * FROM xz_user LIMIT ?,?',[start,obj.count],function(err,result){
	   if(err) throw err;
	   res.send(result);
	});
});

//删除用户06
router.get('/delete',function(req,res){
    var obj=req.query;
	//验证是否为空
	if (!obj.uid)
	{
		res.send({code:401,msg:'uid required'});
		return;
	}
	//执行SQL语句
	pool.query('DELETE FROM xz_user WHERE uid=?',[obj.uid],function(err,result){
	   if(err) throw err;
	   console.log(result);
	   if (result.affectedRows>0)
	   {
		   res.send({code:200,msg:'delete suc'});
	   }else{
	      res.send({code:301,msg:'delete err'});
	   }
	  
	});
});

//4.导出路由器对象 
module.exports=router;








