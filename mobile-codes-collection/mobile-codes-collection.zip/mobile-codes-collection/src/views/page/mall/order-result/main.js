import { fetchModel } from '@/service/api'

export default {
  data () {
    return {}
  },
  methods: {},
  mounted () {}
}
