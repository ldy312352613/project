<template>
  <div class="main p-20rem">
    <h1 class="mb-20rem ta-c fz-16 fw-b ff-yahei">
      其他体系座标转化成百度座标系
    </h1>
    <p class="mb-20rem">
      坐标转换服务是一类Web API接口服务； <br />
      用于将常用的非百度坐标（目前支持GPS设备获取的坐标、google地图坐标、soso地图坐标、amap地图坐标、mapbar地图坐标）转换成百度地图中使用的坐标，并可将转化后的坐标在百度地图JavaScript
      API、静态图API、Web服务API等产品中使用。
    </p>
    <p>
      文档地址：
      <a
        href="http://lbsyun.baidu.com/index.php?title=webapi/guide/changeposition"
        >http://lbsyun.baidu.com/index.php?title=webapi/guide/changeposition</a
      >
    </p>
  </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped></style>
