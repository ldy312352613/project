export default {
  data () {
    return {
      activeNames: []
    }
  },
  methods: {}
}
