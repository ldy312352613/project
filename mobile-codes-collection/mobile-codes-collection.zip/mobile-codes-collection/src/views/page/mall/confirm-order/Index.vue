<template>
  <div>
    <div class="head"></div>
    <div class="cell-group ly ly-j ly-m">
      <div class="ly">
        <div class="cell-group__title">收货地址:</div>
        <div class="cell-group__content">请选择收货地址</div>
      </div>
      <div class="cell-group__icon"></div>
    </div>
    <div class="card ly">
      <img class="card__img" src="http://via.placeholder.com/200x100" alt=""/>
      <div>
        <div class="card__title">商品名称名称名称名称名称名称名称名称名称名称名称名称名称名称</div>
        <div class="ly ly-j">
          <div class="card__sku">单品</div>
          <div class="card__number">x1</div>
        </div>
      </div>
    </div>
    <div class="detail-list">
      <div class="ly ly-j detail-list__item">
        <div class="detail-list__item-title">消耗积分</div>
        <div class="detail-list__item-value">1积分</div>
      </div>
      <div class="ly ly-j detail-list__item">
        <div class="detail-list__item-title">应付款</div>
        <div class="detail-list__item-value">¥15.90</div>
      </div>
      <div class="ly ly-j detail-list__item">
        <div class="detail-list__item-title">运费</div>
        <div class="detail-list__item-value">¥6.00</div>
      </div>
      <div class="ly ly-j detail-list__item">
        <div class="detail-list__item-title">确认收货后返</div>
        <div class="detail-list__item-value">1积分</div>
      </div>
    </div>
    <div class="ly submit-pay">
      <div class="ly submit-pay__text">
        <div>共计: &nbsp; ¥</div>
        <div class="submit-pay__price">15.90</div>
      </div>
      <div class="ta-c">
        <a href="javascript:void(0)" class="submit-pay__btn">立即支付</a>
      </div>
    </div>
  </div>
</template>

<script src="./main.js"></script>
<style scoped src="./style.css"></style>