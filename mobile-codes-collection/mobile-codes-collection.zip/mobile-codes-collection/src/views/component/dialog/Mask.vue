<template>
  <div class="main">
    <div class="mask"></div>
  </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped>
.mask {
  position: fixed;
  z-index: 999;
  top: 0;
  left: 0;
  width: 6.4rem;
  height: 100vh;
  background-color: rgba(0, 0, 0, 0.7);
}
</style>
