//创建商品路由
/*
商品模块  xz_laptop
1添加、2修改、3删除、4检索、5列表	
创建商品路由器 product.js in routes路由文件
*/

//1引入express模板
const express=require('express');
//5.引入连接池模板
const pool=require('../pool.js');
//2.创建路由器对象
var router=express.Router();

//3.1商品添加模块
router.get('/add',function(req,res){
    var obj=req.query;
	//console.log(obj);
    if (!obj.lid)
    {
		res.send({code:401,msg:'lid required'});
		return;
    }if (!obj.family_id)
    {
		res.send({code:402,msg:'family_id required'});
    }if (!obj.title)
    {
		res.send({code:403,msg:'title required'});
		return;
    }if (!obj.price)
    {
		res.send({code:404,msg:'price required'});
		return;
    }if (!obj.shelf_time)
    {
		res.send({code:405,msg:'shelf_titme required'});
		return;
    }
	//执行SQL命令
	pool.query('INSERT INTO xz_laptop SET ?',[obj],function(err,result){
	     if(err)  throw err;
		 console.log(result);
		 if (result.affectedRows>0)
		 {
			 res.send({code:200,msg:'reg suc'});
		 }
	});
	
});


//3.2商品修改模块
//3.3商品删除
//3.4商品检索
//3.5商品列表


//4.导出路由器对象 
module.exports=router;


