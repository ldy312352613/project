//启动文件  服务器
//学子商城 把所学的综合在一起

//1.引入
const express=require('express');
//4.引入路由器 
const userRouter=require('./routes/user.js');         //引入用户
const productRouter=require('./routes/product.js');   //引入商品
const ajaxRouter=require('./routes/myajax.js');       //引入ajax测试
const proRouter=require('./routes/pro.js');           //引入项目路由

//6.引入body-parser
const bodyParser=require('body-parser');
//2.创建web服务器
var server=express();
//3.端口
server.listen(8080);
//托管静态资源到public下
server.use( express.static('public') );
server.use( express.static('ajaxdemo') );
server.use( express.static('mypro') );
//7.使用body-parser中间件，将post请求的数据格式化为对象
server.use( bodyParser.urlencoded({
    extended:false
}) );

//5.使用路由器  使用挂载的url:/user  //要放到最后，因为中间件要过滤
server.use('/user',userRouter);
server.use('/product',productRouter);
server.use('/ajax',ajaxRouter);
server.use('/pro',proRouter);


























