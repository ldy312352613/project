<template>
	<div class="contact-service ta-c">
		<div class="contact-service__icon"></div>
		<div class="contact-service__title">请添加客服微信号</div>
		<div class="contact-service__content">jxc9876543212012</div>
		<a href="javascript:void(0)" class="contact-service__btn">复制微信号</a>
	</div>
</template>

<script src="./main.js"></script>
<style scoped src="./style.css"></style>