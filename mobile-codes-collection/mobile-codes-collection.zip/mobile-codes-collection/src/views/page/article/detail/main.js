import Vue from 'vue'
import fetchModel from '@lucky-joel/vue-fetch-model'
Vue.use(fetchModel)

export default {
  data () {
    return {}
  },
  methods: {}
}
