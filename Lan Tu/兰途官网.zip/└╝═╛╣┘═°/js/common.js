/**
 * Created by Administrator on 2017/3/17.
 */
(function(){
    var $more = $('.header .more');
    $more.click(function(){
        $(this).find('.more-hide').toggle();
    });
})();