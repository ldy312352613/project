export const placeHolder = state => {
  return 'xxx'
}
