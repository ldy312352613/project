<template>
	<div class="">
		<div class="summary">
			<div class="summary__swipe ta-c">
				<div class="summary__title">账户余额(元)</div>
				<div class="summary__price">5.00</div>
				<a class="summary__btn" href="javascript:void(0)">申请提现</a>
			</div>
		</div>
		<div class="detail-list">
			<h2 class="detail-list__title">佣金明细</h2>
			<div class="detail-list__content">
				<div class="item ly ly-j">
					<div>
						<div class="item__title">购买“菲力牛排组合套餐10...”返佣</div>
						<div class="item__date">2018.10.15</div>
					</div>
					<div class="item__income">+5元</div>
				</div>
				<div class="item ly ly-j">
					<div>
						<div class="item__title">提现</div>
						<div class="item__date">2018.10.14</div>
					</div>
					<div class="item__outcome">-10元</div>
				</div>
				<div class="item ly ly-j">
					<div>
						<div class="item__title">推荐人购买“菲力牛排组合套餐10...”返佣</div>
						<div class="item__date">2018.10.14</div>
					</div>
					<div class="item__income">+10元</div>
				</div>
			</div>
		</div>
	</div>
</template>

<script src="./main.js"></script>

<style scoped src="./style.css"></style>

