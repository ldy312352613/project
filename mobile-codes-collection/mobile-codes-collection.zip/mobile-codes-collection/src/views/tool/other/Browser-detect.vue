<template>
  <div class="main">
    当前设备：{{ isAndroid ? 'Android' : '' }} {{ isIOS ? 'ios' : '' }}
  </div>
</template>

<script>
export default {
  data () {
    return {}
  },
  methods: {}
}
</script>

<style scoped></style>
