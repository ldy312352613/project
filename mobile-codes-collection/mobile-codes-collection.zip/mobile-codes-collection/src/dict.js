export const gender = [
  {
    id: 1,
    name: '男'
  },
  {
    id: 2,
    name: '女'
  }
]

export const musicTypes = [
  {
    id: 'pop',
    name: '流行'
  },
  {
    id: 'classic',
    name: '经典'
  }
]
