<template>
  <div class="logistics-detail">
    <ul class="logistics-detail__item">
      <li class="ly  item">
        <div class="item__time ta-r">
          <div>12-08<br>
          22:21</div>
        </div>
        <div class="item__content">苏州转运中心 已收入</div>
      </li>
      <li class="ly  item">
        <div class="item__time ta-r">
          <div>12-08<br>
            20:25</div>
        </div>
        <div class="item__content">无锡转运中心公司 已发出，下一站 苏州转运中心</div>
      </li>
      <li class="ly  item">
        <div class="item__time ta-r">
          <div>12-08<br>
          00:01</div>
        </div>
        <div class="item__content item__content--last">无锡转运动型 已经收入</div>
      </li>
    </ul>
  </div>
</template>
<script src="./main.js"></script>
<style scoped src="./style.css"></style>