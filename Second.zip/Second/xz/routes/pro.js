//1.引入
const express=require('express');

//5.引入连接池模块
const pool=require('../pool.js');  //../ 连接上级目录下的js文件

//2.创建路由器对象
var router=express.Router();

//3添加路由 post 登陆   login
   router.post("/login",(req,res)=>{
  var $uname=req.body.uname;
  var $upwd=req.body.upwd;
  if(!$uname){
	res.send("用户名不存在");
	return;
  }
  if(!$upwd){
	res.send("密码不存在");
	return;
  }
  pool.query("select * from xz_user where uname=? and upwd=?",[$uname,$upwd],(err,result)=>{
     if(err) throw err;
	 if(result.length>0){
		res.send("登录成功！");
	 }else{
		res.send("登录用户名或密码错误");
	 }
  });
});

//查询用户所有数据，并响应给前端  list
router.get('/list',(req,res)=>{	 
	 pool.query("select * from xz_user",(err,result)=>{
		 if(err) throw err;
		 res.send(result);
	 });
  }); 
  

//删除数据库中数据 get   deleteUser
router.get('/deleteUser',(req,res)=>{
	 var $uid=req.query.uid;
	  if (!$uid)
	  {
		  res.send("uid未找到");
		  return;
	  }
	  var sql="delete from xz_user where uid=?";
    pool.query(sql,[$uid],(err,result)=>{
	     if(err) throw err;
		 console.log($uid);
		 console.log(result);
		 if(result.affectedRows>0)
		 {			
			 res.send("1"); //删除成功
		 }else{
		   res.send("0");  //删除失败
		 }
	});
});

//4.根据uid检索用户
router.get('/query',(req,res)=>{
    var $uid=req.query.uid;
	if (!$uid)
	{
		res.send("uid未找到");
		return;
	}
	//查数据库
     var sql="select * from xz_user where uid=?";
	 pool.query(sql,[$uid],(err,result)=>{
	    if(err) throw err;
		if(result.length>0)
		{
			res.send(result[0]); 
		}else{
		    res.send("没有该用户信息");
		}
	 })
});

//修改模块
       router.post('/update',(req,res)=>{
	   var $uid=req.body.uid;
	   var $uname=req.body.uname;	   
	   var $upwd=req.body.upwd;
	   var $email=req.body.email;
	   var $phone=req.body.phone;
	   var $user_name=req.body.user_name;
	   var $gender=req.body.gender;
	   if(!$uid){
		   res.send("用户ID未接收到"); return;
	   }
	   if(!$uname){
		   res.send("用户名未接收到");  return;
	   }
	   if(!$upwd){
		   res.send("用户密码未接收到");  return;
	   }
	   if(!$email){
		   res.send("邮箱未接收到");  return;
	   }
	   if(!$phone){
		   res.send("用户电话未接收到");  return;
	   }
	   if(!$user_name){
		   res.send("真实姓名未接收到");  return;
	   }
	   if(!$gender){
		   res.send("用户性别未接收到");  return;
	   }  
 //SQL语句
	   var sql="UPDATE  xz_user  SET  uname=?,upwd=?,email=?,phone=?,user_name=?,gender=? "+" WHERE uid=?";
	   pool.query(sql,[$uname,$upwd,$email,$phone,$user_name,$gender,$uid],(err,result)=>{
	     if(err) throw err;
		 if(result.affectedRows>0)
		{
			console.log(result.affectedRows);
			res.send("1");   //成功
		}else{
		    res.send("0");
		}
	   });
	 });



//4.导出路由器对象 
module.exports=router;








